#include "wiring_adc.h"

static void adc_callback(void)
{
    
}

static void adc_init(void)
{
	
}

static void adc_close(void)
{
   
}   /* End of function adc_close() */



uint32_t adc_read(void)
{
  

    return 0;
}
