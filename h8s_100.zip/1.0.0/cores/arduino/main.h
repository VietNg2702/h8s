#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

void main(void);    

#endif		/* MAIN_UART_H_INCLUDED */