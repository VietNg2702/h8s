#ifndef WIRING_ADC_H__
#define WIRING_ADC_H__

#include <stdint.h>
#include <stdbool.h>

uint32_t adc_read(void);

#endif