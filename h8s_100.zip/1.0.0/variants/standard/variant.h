
#ifndef _VARIANT_H8S
#define _VARIANT_H8S


#include <stdint.h>




#endif 
