
#ifndef _VARIANT_H8S
#define _VARIANT_H8S


#include <stdint.h>



/*----------------------------------------------------------------------------
*        Headers
*----------------------------------------------------------------------------*/

#include "Arduino.h"
#include "pins_arduino.h"

#endif 
