#ifndef VARIANT_H__
#define VARIANT_H__

#include "variant.h"



#endif