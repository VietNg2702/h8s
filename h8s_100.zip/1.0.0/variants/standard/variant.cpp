#ifndef VARIANT_H__
#define VARIANT_H__

#include "variant.h"

UARTClass Serial(6,8);

#endif